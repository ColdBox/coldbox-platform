if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AppUser]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[AppUser]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[newUUID]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[newUUID]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE FUNCTION [newUUID](@GUID varchar(36))
RETURNS varchar(35)
AS
BEGIN
 RETURN left(@GUID, 23) + right(@GUID,12)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE TABLE [dbo].[AppUser] (
	[AppUserId] [char] (35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Username] [varchar] (30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Password] [char] (32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[FirstName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[LastName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Email] [varchar] (250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[UpdatedOn] [datetime] NOT NULL ,
	[CreatedOn] [datetime] NOT NULL ,
	[isActive] [bit] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AppUser] ADD 
	CONSTRAINT [DF__AppUser__AppUser__77BFCB91] DEFAULT ([dbo].[newUUID](newid())) FOR [AppUserId],
	CONSTRAINT [DF__AppUser__Updated__78B3EFCA] DEFAULT (getdate()) FOR [UpdatedOn],
	CONSTRAINT [DF__AppUser__Created__79A81403] DEFAULT (getdate()) FOR [CreatedOn],
	CONSTRAINT [DF__AppUser__isActiv__7A9C383C] DEFAULT (0) FOR [isActive],
	CONSTRAINT [PK_AppUser] PRIMARY KEY  CLUSTERED 
	(
		[AppUserId]
	)  ON [PRIMARY] 
GO

CREATE PROCEDURE spSelectNextN
	@TableName VARCHAR(250),
	@Columns VARCHAR(1000),
	@IdentityColumn VARCHAR(64),
	@GroupNumber INT,
	@GroupSize INT,
	@SqlWhere VARCHAR(4000),
	@SqlOrderBy VARCHAR(1000)

AS

DECLARE @SqlString NVARCHAR(4000)
DECLARE @SqlString2 NVARCHAR(4000)
DECLARE @PreviousRecords INT

SET @PreviousRecords = (@GroupSize * @GroupNumber) - @GroupSize

SET @SqlString2 = N'(SELECT TOP ' + 
	CAST(@PreviousRecords AS NVARCHAR(32)) + 
	N' ' + @IdentityColumn + 
	N' FROM ' + 
	@TableName

IF @SqlWhere + '' <> ''
	BEGIN
		SET @SqlString2 = @SqlString2 + 
			N' WHERE ' + 
			@SqlWhere
	END

IF @SqlOrderBy + '' <> ''
	BEGIN
		SET @SqlString2 = @SqlString2 + 
			N' ORDER BY ' + 
			@SqlOrderBy
	END

SET @SqlString2 = @SqlString2 + N')'

SET @SqlString = N'SELECT TOP ' + 
	CAST(@GroupSize AS NVARCHAR(32)) + 
	N' ' + 
	@Columns + 
	N' FROM ' + 
	@TableName + 
	N' WHERE (' + 
	@IdentityColumn + 
	N' NOT IN ' + 
	@SqlString2 + 
	N')'

IF @SqlWhere + '' <> ''
	BEGIN
		SET @SqlString = @SqlString + 
			N' AND ' + 
			@SqlWhere
	END

IF @SqlOrderBy + '' <> ''
	BEGIN
		SET @SqlString = @SqlString + 
			N' ORDER BY ' + 
			@SqlOrderBy
	END

EXEC sp_executesql @SqlString
DECLARE @AddSQL NVARCHAR(4000)
SET @AddSQL = N'Select count(*) as totalRecords from ' + @TableName + N' Where ' + @SqlWhere
EXEC sp_executesql  @AddSQL
GO

INSERT INTO [AppUser]
           ([AppUserId]
           ,[Username]
           ,[Password]
           ,[FirstName]
           ,[LastName]
           ,[Email]
           ,[isActive])
     VALUES
			('E0DC3A63-E37C-4BDC-9B8C314C0982E203',
			'admin',
			'21232F297A57A5A743894A0E4A801FC3',
			'Admin',
			'MSSQL',
			'admin@admin.com',
			1)