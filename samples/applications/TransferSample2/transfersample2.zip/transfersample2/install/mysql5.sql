# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                 localhost
# Database:             transfersample
# Server version:       5.0.26-community-nt
# Server OS:            Win32
# Target-Compatibility: Standard ANSI SQL
# HeidiSQL version:     3.1 RC1 Revision: 1064
# --------------------------------------------------------

/*!40100 SET CHARACTER SET latin1;*/
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'transfersample'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "transfersample" /*!40100 DEFAULT CHARACTER SET latin1 */;

USE "transfersample";


#
# Table structure for table 'users'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "users" (
  "usr_id" int(3) NOT NULL auto_increment,
  "usr_username" varchar(50) NOT NULL,
  "usr_password" char(32) NOT NULL,
  "usr_firstname" varchar(50) NOT NULL,
  "usr_lastname" varchar(50) NOT NULL,
  "usr_email" varchar(250) NOT NULL,
  "usr_createdon" timestamp NOT NULL default CURRENT_TIMESTAMP,
  "usr_updatedon" datetime default '0000-00-00 00:00:00',
  "usr_isactive" tinyint(1) NOT NULL default '0',
  "ust_id" int(3) unsigned NOT NULL,
  PRIMARY KEY  ("usr_id")
) /*!40100 DEFAULT CHARSET=latin1*/;



#
# Dumping data for table 'users'
#

/*!40000 ALTER TABLE "users" DISABLE KEYS;*/
LOCK TABLES "users" WRITE;
REPLACE INTO "users" ("usr_id", "usr_username", "usr_password", "usr_firstname", "usr_lastname", "usr_email", "usr_createdon", "usr_updatedon", "usr_isactive", "ust_id") VALUES
	(1,'ernst','F66F8C3C3246E6819AAA792638114EDA','Ernst','van der Linden','evdlinden@behindthe.net','2007-12-25 23:53:32','2007-12-25 23:53:32',1,'1');
REPLACE INTO "users" ("usr_id", "usr_username", "usr_password", "usr_firstname", "usr_lastname", "usr_email", "usr_createdon", "usr_updatedon", "usr_isactive", "ust_id") VALUES
	(2,'admin','21232F297A57A5A743894A0E4A801FC3','Admin','MySQL','admin@admin.com','2007-07-31 15:01:50','1999-01-01 00:00:01',0,'1');
REPLACE INTO "users" ("usr_id", "usr_username", "usr_password", "usr_firstname", "usr_lastname", "usr_email", "usr_createdon", "usr_updatedon", "usr_isactive", "ust_id") VALUES
	(3,'spidy','32252792B9DCCF239F5A5BD8E778DBC2','Ruben','Waitz','ruben@amtex.nl','2008-01-09 15:28:29','2008-01-09 15:28:29',1,'2');
UNLOCK TABLES;
/*!40000 ALTER TABLE "users" ENABLE KEYS;*/


#
# Table structure for table 'usertypes'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "usertypes" (
  "ust_id" int(3) unsigned NOT NULL auto_increment,
  "ust_desc" varchar(50) NOT NULL,
  PRIMARY KEY  ("ust_id")
) /*!40100 DEFAULT CHARSET=latin1*/;



#
# Dumping data for table 'usertypes'
#

/*!40000 ALTER TABLE "usertypes" DISABLE KEYS;*/
LOCK TABLES "usertypes" WRITE;
REPLACE INTO "usertypes" ("ust_id", "ust_desc") VALUES
	('1','Administrator');
REPLACE INTO "usertypes" ("ust_id", "ust_desc") VALUES
	('2','User');
UNLOCK TABLES;
/*!40000 ALTER TABLE "usertypes" ENABLE KEYS;*/
/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
