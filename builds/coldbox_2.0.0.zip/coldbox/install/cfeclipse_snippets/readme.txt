ColdBox 1.1.0 Eclipse Snippets

Just place the coldbox snippets folder under your snippets directory. 
The keyCombo.properties you can place in the root of your drive. Why? well, 
cfeclipse has a bug and places this file on your root drive. So until cfeclipse 
has this fixed in the next version, place it here.  Enjoy!!

Luis Majano
Jn 3:16