********************************************************************************
Copyright 2005-2007 ColdBox Framework by Luis Majano and Ortus Solutions, Corp
www.coldboxframework.com | www.luismajano.com | www.ortussolutions.com
********************************************************************************

Welcome to the ColdBox Application Template

This is a skeleton for you to start a new ColdBox application or you can use the 
Application Generator included in the ColdBox Dashboard. Below is a sample
ColdBox application directory structure.  You need to follow this structure in order
for ColdBox to work via its conventions. You can also change the conventions using
the ColdBox Dashboard or the settings.xml

******************************************************************************
Sample Directory Structure For Your Application
******************************************************************************
-ApplicationFolder
	-config (Your config folder, where your config.xml.cfm resides) REQUIRED
	-handlers (Your ColdBox event handlers, can be orgainzed into folders) REQUIRED
	-layouts  (Your layouts) REQUIRED
	-views (Your views, can be orgainzed into folders) REQUIRED
	-includes (Your include files if used.) OPTIONAL-includes a generic custom error template
	-tags (Your cf tags if used) OPTIONAL
	-images (Your images) OPTIONAL
	-logs (For ColdBox Logging) OPTIONAL
	-{Any other folder(s) you want} OPTIONAL
	
******************************************************************************
NAMING CONVENTIONS
******************************************************************************
Views (Optional): All my views start with 'vw', you can use 'dsp' anything you
like, as long as you remember the name.
	ex: vwMyview.cfm, vwHello.cfm, dspHello.cfm

Layouts (Optional): All my layouts start with 'Layout.'. Again you can 
use anything you like.
	ex: Layout.Main.cfm, Layout.Popup.cfm, dspPopup.cfm, dspLayout.cfm

Event Handlers (REQUIRED): 

All event handlers method calls follow this regular expression:
(dsp|do|on)[a-zA-Z]+ and they need to have an access of public in 
order for ColdBox to register them. You can still create private methods
but they can only be called from within the same handler.

ex: ehGeneral.doLogin, ehTools.doParse, ehGeneral.dspHome, ehGeneral.dspContactInfo

All event handlers start with 'eh' + the name. (OPTIONAL)
You can name the handlers in whatever format you like.
ex: ehGeneral.cfc, ehLuis.cfc, ehTools.cfc, ehBase.cfc, myhandler.cfc

Valid PUBLIC method names should start with "on, dsp, do"
PRIVATE methods do not have a nomenclature.

******************************************************************************
QUICK START
******************************************************************************
How to start? 

1) Start off by copying the ApplicationTemplate folder to your web root and
   naming it to something you want. Remember that you need to have installed
   ColdBox first. Simply by copying the coldbox distribution directory to the
   web root. /WEBROOT/coldbox

2) Open the config/config.xml.cfm file and change the AppName setting to whatever you want.
    
   You can read the config.xml guide in order to understand all the variables in this file
   and adjust if needed.  

3) Optional step, skip to step 4.
   If you need to change the name property of your Application.cfc or
   Application.cfm template.
   Oopen the file Application.cfc or Application.cfm and change the name
   property to whatever you want it to be. Remember that every application will need
   its own name property. Also, please note that ColdBox uses the application
   scope as a requirement. 
   
   - The client scope needs to be enabled if using the clientstorage plugin.
   - The messagebox plugin can use the session or client scope. By default it uses session.

4) Now that you have completed editing your config and Application.cfc, you are ready to see 
   results. Point your web browser to your application folder and you will see a message display:

OPTIONAL: Skip all the steps, just fire up the ColdBox Dashboard and run the Application Generator.

UNIT TESTS: You will also find the unit tests ready for the event handlers inside the handlers
            directory under the name tests. You will find a test suite and two test cases.

Welcome to Coldbox!!

Now get your mind out of procedural code, dive into OO Programming. Please make sure
to fasten your seat belts, it WILL GET BUMPY!!


