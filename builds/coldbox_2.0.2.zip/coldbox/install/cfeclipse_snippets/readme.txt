ColdBox Eclipse Snippets

Just place the coldbox snippets folder under your snippets directory of your CFEclipse installation.

Luis Majano
Jn 3:16