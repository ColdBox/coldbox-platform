while(1);
[
	{
		"name": "Great Wall of China",
		"photo": "../../demos/gallery/galleries/china/images/china_01.jpg",
		"thumbnail": "../../demos/gallery/galleries/china/thumbnails/china_01.jpg"
	},
	{
		"name": "Hong Kong Skyline",
		"photo": "../../demos/gallery/galleries/china/images/china_24.jpg",
		"thumbnail": "../../demos/gallery/galleries/china/thumbnails/china_24.jpg"
	},
	{
		"name": "Great Pyramid of Giza",
		"photo": "../../demos/gallery/galleries/egypt/images/egypt_01.jpg",
		"thumbnail": "../../demos/gallery/galleries/egypt/thumbnails/egypt_01.jpg"
	},
	{
		"name": "Great Sphynx",
		"photo": "../../demos/gallery/galleries/egypt/images/egypt_07.jpg",
		"thumbnail": "../../demos/gallery/galleries/egypt/thumbnails/egypt_07.jpg"
	},
	{
		"name": "Eifel Tower",
		"photo": "../../demos/gallery/galleries/paris/images/paris_05.jpg",
		"thumbnail": "../../demos/gallery/galleries/paris/thumbnails/paris_05.jpg"
	},
	{
		"name": "Arc de Triomphe",
		"photo": "../../demos/gallery/galleries/paris/images/paris_10.jpg",
		"thumbnail": "../../demos/gallery/galleries/paris/thumbnails/paris_10.jpg"
	}
]