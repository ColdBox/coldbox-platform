{
	color: "red",
	value: "#f00"
}
