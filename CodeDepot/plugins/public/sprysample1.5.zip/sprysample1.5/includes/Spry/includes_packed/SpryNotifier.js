// SpryNotifier.js - version 0.1 - Spry Pre-Release 1.6
//
// Copyright (c) 2007. Adobe Systems Incorporated.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
//   * Redistributions of source code must retain the above copyright notice,
//     this list of conditions and the following disclaimer.
//   * Redistributions in binary form must reproduce the above copyright notice,
//     this list of conditions and the following disclaimer in the documentation
//     and/or other materials provided with the distribution.
//   * Neither the name of Adobe Systems Incorporated nor the names of its
//     contributors may be used to endorse or promote products derived from this
//     software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('9 4;3(!4)4={};3(!4.6)4.6={};4.6.b=8(){2.5=[];2.c=0};4.6.b.f.t=8(7){3(!7)g;9 d=2.5.h;j(9 i=0;i<d;i++){3(2.5[i]==7)g}2.5[d]=7};4.6.b.f.r=8(7){3(!7)g;j(9 i=0;i<2.5.h;i++){3(2.5[i]==7){2.5.w(i,1);p}}};4.6.b.f.m=8(e,k){3(!e)g;3(!2.c){9 d=2.5.h;j(9 i=0;i<d;i++){9 a=2.5[i];3(a){3(x a=="8")a(e,2,k);v 3(a[e])a[e](2,k)}}}};4.6.b.f.l=8(){3(--2.c<0){2.c=0;4.q.s("u l() y!\\n")}};4.6.b.f.o=8(){++2.c};',35,35,'||this|if|Spry|observers|Utils|observer|function|var|obs|Notifier|suppressNotifications|len|methodName|prototype|return|length||for|data|enableNotifications|notifyObservers||disableNotifications|break|Debug|removeObserver|reportError|addObserver|Unbalanced|else|splice|typeof|call'.split('|'),0,{}))
